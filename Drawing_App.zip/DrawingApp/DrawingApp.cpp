#include <iostream>
#include "imgui/imgui.h"
#include "imgui/imgui-SFML.h"
#include <SFML/Graphics.hpp>

using namespace sf;
using namespace std;
using namespace ImGui;
using namespace SFML;

class UiWindow
{
private:
	RectangleShape bar;
	RectangleShape cursor;
	bool is_Focused;
	bool ratio = 0;

public:

	UiWindow()
	{
		cursor.setFillColor(Color::Black);
		bar.setSize(Vector2f(250, 1000));
		bar.setFillColor(Color(79, 84, 92));
		bar.setPosition(0, 0);
	}

	int initWindow(bool& gridBased, float& size, float& sizex, float& sizey, bool& ratio, RenderWindow& window, float setColor[], RenderTexture& texture)
	{
		SetNextWindowSize(ImVec2(250, 350));
		SetNextWindowPos(ImVec2(0, 0));

		Begin("Options Panel");
		Checkbox("Grid Based Drawing", &gridBased);
		Checkbox("Lock Pen Size Aspect Ratio", &ratio);
		if (ratio == 1)
		{
			SliderFloat("Pen Size", &size, 5, 60);
			cursor.setSize(Vector2f(size, size));
		}
		if (ratio == 0)
		{
			SliderFloat("Pen Size X", &sizex, 5, 60);
			SliderFloat("Pen Size Y", &sizey, 5, 60);
			cursor.setSize(Vector2f(sizex, sizey));
		}
		ColorPicker3("Color Pick", setColor);

		cursor.setPosition(Mouse::getPosition(window).x, Mouse::getPosition(window).y);

		if (!IsWindowFocused())
			return 0;
	    if (IsWindowFocused())
			return 1;
	
		End();
	}

	void drawCosmeticUi(RenderWindow& window)
	{
		window.draw(bar);
		window.draw(cursor);
	}
	
};

class Pixel
{
private:
	RectangleShape pixel;
	Texture shapeTexture;
	UiWindow uiWin;

public:

	Pixel()
	{
		shapeTexture.loadFromFile("1.png");
		pixel.setPosition(-9999, 99999);
		pixel.setTexture(&shapeTexture);
		pixel.setFillColor(Color::Black);
	}

	void paint(bool& ratio, float& sizex, float& sizey, RenderWindow& window, Pixel& p, vector<Pixel>& pixels, float& size, float setColor[])
	{
		if(ratio == 1)
			pixel.setSize(Vector2f(size, size));
		if(ratio == 0)
			pixel.setSize(Vector2f(sizex, sizey));
		pixel.setFillColor(Color(float(setColor[0] * 255), float(setColor[1] * 255), float(setColor[2] * 255)));

		if (Mouse::isButtonPressed(Mouse::Left))
		{
			//pixels.clear();
			pixel.setPosition(Mouse::getPosition(window).x, Mouse::getPosition(window).y);
			pixels.push_back(Pixel(p));
		}
	}

	void draw(RenderWindow& window, Pixel& p, vector<Pixel>& pixels, RenderTexture& texture, bool& gridBased, float& size, float setColor[])
	{
		for (int i = 0; i < pixels.size(); i++)
			window.draw(pixels[i].pixel);
		for (int i = 0; i < pixels.size(); i++)
			texture.draw(pixels[i].pixel);

		SetNextWindowSize(ImVec2(250, 55));
		SetNextWindowPos(ImVec2(0, 350));
		Begin("Save Panel");
		if (Button("Save"))
			texture.getTexture().copyToImage().saveToFile("Saves/save.png");

		End();
	}
};

int main()
{ 
	int resx = 1300;
	int resy = 800;

	bool gridBased = false;

	RenderWindow window(VideoMode(resx, resy), "Drawing App");
	sf::Image icon;
	icon.loadFromFile("Files/image.png");
	window.setIcon(icon.getSize().x, icon.getSize().y, icon.getPixelsPtr());
	Init(window);
	Clock clock;
	Event eve;
	Clock deltaclock;

	View view(FloatRect(0, 0, resx - 250, resy));
	view.setCenter(775, 400);
	RectangleShape viewDetect(Vector2f(resx - 250, resy));
	viewDetect.setPosition(view.getCenter().x, view.getCenter().y);
	viewDetect.setFillColor(Color::Red);
	viewDetect.setOrigin((resx - 250) / 2, (resy) / 2);

	float size = 10;
	float sizex = 10;
    float sizey = 10;
	bool ratio = 0;
	float setColor[3] = { 1 / 255, 1 / 255 , 1 / 255 };
	Pixel p;
	vector<Pixel>pixels;

	RenderTexture texture;
	texture.create(resx, resy);

	UiWindow uiWin;

	while (window.isOpen())
	{
		while (window.pollEvent(eve))
		{
			ProcessEvent(eve);
			if (eve.type == Event::Closed)
				window.close();
		}


		Time time = clock.getElapsedTime();
		clock.restart().asSeconds();
		//cout << int(1.0f / time.asSeconds()) << endl;


		Update(window, deltaclock.restart());
		texture.setView(view);
		texture.clear(Color::White);
		window.clear(Color::White);
		//window.draw(viewDetect);
		if (uiWin.initWindow(gridBased, size, sizex, sizey, ratio, window, setColor, texture) == 0)
			p.paint(ratio, sizex, sizey, window, p, pixels, size, setColor);
		p.draw(window, p, pixels, texture, gridBased, size, setColor);
		uiWin.drawCosmeticUi(window);
		texture.display();
		Render(window);
		window.display();
	}
	Shutdown();
}